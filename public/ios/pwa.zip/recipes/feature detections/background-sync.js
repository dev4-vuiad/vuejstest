if ("SyncManager" in window) {

    //do stuff here

}