    //push notification feature detection
    if ("PushManager" in window) {

        //do push stuff here

    }